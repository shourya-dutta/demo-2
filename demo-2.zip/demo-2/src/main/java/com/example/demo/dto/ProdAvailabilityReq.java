package com.example.demo.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProdAvailabilityReq {

	private String storeNo;
	private String productId;
	private Double reqQty;
	private String reqDate;
	private String status;

	public ProdAvailabilityReq() {
		// TODO Auto-generated constructor stub
	}

	public ProdAvailabilityReq(String storeNo, String productId, Double reqQty, String reqDate) {
		super();
		this.storeNo = storeNo;
		this.productId = productId;
		this.reqQty = reqQty;
		this.reqDate = reqDate;
	}

}
