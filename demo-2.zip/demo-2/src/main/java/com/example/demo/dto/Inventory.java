package com.example.demo.dto;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Inventory {

	private String productId;
	private String prodName;
	private String UOM;
	private Double availQty;
	private Date availDate;

	public Inventory() {
	}

	public Inventory(String productId, String prodName, String uOM, Double availQty, Date availDate) {
		super();
		this.productId = productId;
		this.prodName = prodName;
		UOM = uOM;
		this.availQty = availQty;
		this.availDate = availDate;
	}

}
