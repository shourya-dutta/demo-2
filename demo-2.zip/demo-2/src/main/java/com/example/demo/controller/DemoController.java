package com.example.demo.controller;

import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.Inventory;
import com.example.demo.dto.InventoryReq;
import com.example.demo.dto.ProdAvailabilityReq;
import com.example.demo.service.DemoService;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class DemoController {

	@Autowired
	private DemoService demoService;

	//problem 1
	@PostMapping("getInvPicture")
	public Object getInvPicture(@RequestBody InventoryReq payload) throws Exception {

		String dtStr = payload.getReqDate();

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
		Date dt = sdf.parse(dtStr);

		Date startDate = sdf.parse("2021-03-19");
		Date lastDate = sdf.parse("2021-03-28");

		if (dt.before(startDate)) {
			return new ResponseEntity<>("Date need to be greater or equals than 2021-03-19", HttpStatus.BAD_REQUEST);
		}

		if (dt.after(lastDate)) {
			return new ResponseEntity<>("Date need to be befoew or equals than 2021-03-28", HttpStatus.BAD_REQUEST);
		}

		return demoService.getInvPicture(dt);
	}
	
	
	@PostMapping("getProdAvailability")
	public Object getProdAvailability(@RequestBody ProdAvailabilityReq payload) throws Exception {
		
		return demoService.getProdAvailability(payload);
		
	}

}
