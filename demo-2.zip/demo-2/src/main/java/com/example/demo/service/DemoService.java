package com.example.demo.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.stereotype.Service;

import com.example.demo.dto.Availability;
import com.example.demo.dto.Capacity;
import com.example.demo.dto.Inventory;
import com.example.demo.dto.ProdAvailabilityReq;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class DemoService {

	public Inventory getInvPicture(Date orderDate) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");

		List<Inventory> invetoryList = Stream.of(new Inventory("Prod1", "Shirt", "EACH", 10.0, sdf.parse("2021-03-20")),
				new Inventory("Prod1", "Shirt", "EACH", 20.0, sdf.parse("2021-03-21")),
				new Inventory("Prod1", "Shirt", "EACH", 20.0, sdf.parse("2021-03-28"))).toList();

		Calendar c = Calendar.getInstance();
		c.setTime(orderDate);
		c.add(Calendar.DATE, 10);
		Date lastDate = c.getTime();

		List<Inventory> filterList = invetoryList.stream().filter(o -> {
			if (o.getAvailDate().compareTo(orderDate) >= 0 && o.getAvailDate().compareTo(lastDate) <= 0) {
				return true;
			}
			return false;
		}).collect(Collectors.toList());

		Double totalVal = invetoryList.stream().filter(o -> {
			if (o.getAvailDate().compareTo(orderDate) >= 0 && o.getAvailDate().compareTo(lastDate) <= 0) {
				return true;
			}
			return false;
		}).mapToDouble(i -> Double.valueOf(i.getAvailQty())).sum();

		log.info("filterList", filterList);
		log.info("totalVal", totalVal);

		Inventory resp = new Inventory();
		resp.setProdName("Shirt");
		resp.setProductId("Prod1");
		resp.setAvailQty(totalVal);

		return resp;
	}

	public Object getProdAvailability(ProdAvailabilityReq payload) throws Exception {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");

		ExecutorService executor = Executors.newFixedThreadPool(5);
		List<Callable<Object>> callableList = new ArrayList<>();

		List<Future<Object>> results = null;
		try {
			callableList.add(() -> getAvailability(payload.getStoreNo(), payload.getProductId(),
					sdf.parse(payload.getReqDate())));
			callableList.add(
					() -> getCapacity(payload.getStoreNo(), payload.getProductId(), sdf.parse(payload.getReqDate())));

			results = executor.invokeAll(callableList);

			Availability availability = (Availability) results.get(0).get();
			Capacity capacity = (Capacity) results.get(1).get();

			double capacityQty = 0;
			double availableQty = 0;

			if (availability != null) {
				availableQty = availability.getAvailQty();
			}

			if (capacity != null) {
				capacityQty = capacity.getNoOfOrdersAccepted();
			}

			if (capacityQty == 0 || availableQty == 0) {
				payload.setStatus("Not available");
			} else {
				payload.setStatus(Double.toString(capacityQty));
			}

		} catch (InterruptedException e) {
			throw new RuntimeException(e);
		} finally {
			executor.shutdown();
		}

		return payload;
	}

	private Availability getAvailability(String storeNo, String productId, java.util.Date date) throws ParseException {

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");

		List<Availability> availabilityList = Stream
				.of(new Availability("Store001", "Prod1", sdf.parse("2021-02-19"), 1.0),
						new Availability("Store001", "Prod1", sdf.parse("2021-02-20"), 3.0),
						new Availability("Store001", "Prod1", sdf.parse("2021-02-21"), 0.0))
				.toList();

		Availability availability = availabilityList.stream().filter(o -> {
			if (o.getStoreNo().equalsIgnoreCase(storeNo) && o.getProductId().equals(productId)
					&& o.getDate().compareTo(date) == 0) {
				return true;
			}
			return false;
		}).findFirst().orElse(null);

		return availability;
	}

	private Capacity getCapacity(String storeNo, String productId, java.util.Date date) throws ParseException {

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");

		List<Capacity> capacityList = Stream.of(new Capacity("Store001", "Prod1", sdf.parse("2021-02-19"), 0.0),
				new Capacity("Store001", "Prod1", sdf.parse("2021-02-20"), 2.0),
				new Capacity("Store001", "Prod1", sdf.parse("2021-02-21"), 2.0),
				new Capacity("Store001", "Prod1", sdf.parse("2021-02-22"), 0.0)).toList();

		Capacity capacity = capacityList.stream().filter(o -> {
			if (o.getStoreNo().equalsIgnoreCase(storeNo) && o.getProductId().equals(productId)
					&& o.getDate().compareTo(date) == 0) {
				return true;
			}
			return false;
		}).findFirst().orElse(null);

		return capacity;
	}

}
