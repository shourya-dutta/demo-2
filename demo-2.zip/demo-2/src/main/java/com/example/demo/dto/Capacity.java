package com.example.demo.dto;

import java.util.Date;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Capacity {

	private String storeNo;
	private String productId;
	private java.util.Date date;
	private Double noOfOrdersAccepted;

	public Capacity() {
		// TODO Auto-generated constructor stub
	}

	public Capacity(String storeNo, String productId, Date date, Double noOfOrdersAccepted) {
		super();
		this.storeNo = storeNo;
		this.productId = productId;
		this.date = date;
		this.noOfOrdersAccepted = noOfOrdersAccepted;
	}

}
