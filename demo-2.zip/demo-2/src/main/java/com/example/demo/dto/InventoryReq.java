package com.example.demo.dto;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class InventoryReq {

	private String productId;
	private String prodName;
	private String reqDate;

	public InventoryReq() {
		// TODO Auto-generated constructor stub
	}
	
	

}
