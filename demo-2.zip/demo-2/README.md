## Run Jar
java -jar <jar file name>
Ex- java -jar demo-2-0.0.1-SNAPSHOT.jar




#Problem 1

Request url: 
http://localhost:8080/getInvPicture

Request Body:
{
    "productId": "Prod1",
    "prodName": "Shirt",
    "reqDate": "2021-03-23"
}


Response Body:
{
    "productId": "Prod1",
    "prodName": "Shirt",
    "availQty": 20.0,
    "availDate": null,
    "uom": null
}


#Problem 2

Request url: 
http://localhost:8080/getProdAvailability

Request Body:
{
    "storeNo": "Store001",
    "productId": "Prod1",
    "reqQty": 2,
    "reqDate": "2021-02-19"
}


Response Body:
{
    "storeNo": "Store001",
    "productId": "Prod1",
    "reqQty": 2.0,
    "reqDate": "2021-02-19",
    "status": "Not available"
}


